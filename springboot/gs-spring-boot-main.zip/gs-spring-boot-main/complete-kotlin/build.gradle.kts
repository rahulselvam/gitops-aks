plugins {
  id("org.springframework.boot") version "4.0.1"
  id("io.spring.dependency-management") version "1.1.7"
  kotlin("jvm") version "2.2.21"
  kotlin("plugin.spring") version "2.2.21"
}

group = "com.example"
version = "0.0.1-SNAPSHOT"

java {
  toolchain {
    languageVersion = JavaLanguageVersion.of(17)
  }
}

repositories {
  mavenCentral()
}
dependencies {
  // tag::actuator[]
  implementation("org.springframework.boot:spring-boot-starter-actuator")
  // end::actuator[]
  implementation("org.springframework.boot:spring-boot-starter-webmvc")
  // tag::tests[]
  testImplementation("org.springframework.boot:spring-boot-starter-webmvc-test")
  // end::tests[]
}

kotlin {
  compilerOptions {
    freeCompilerArgs.addAll("-Xjsr305=strict", "-Xannotation-default-target=param-property")
  }
}

tasks.withType<Test> {
  useJUnitPlatform()
}
